const express = require("express");
const serviceController = require('../controller/service_controller');

const router = express.Router();

router.get('/showServices', serviceController.showServices);
router.get('/addServicePage', serviceController.addServicePage);
router.get('/details/:id', serviceController.detailsPage);

router.post('/addService',  serviceController.addService)

router.get('/updateService/:id', serviceController.getServiceById);
router.post('/updateService', serviceController.updateService);

module.exports = router;