const express = require("express");
const customerController = require('../controller/customer_controller');

const router = express.Router();

router.get('/showCustomers', customerController.showCustomers);
router.get('/addCustomerPage', customerController.addCustomerPage);

router.get('/deleteCustomer/:id', customerController.deleteCustomer);
router.post('/addCustomer', customerController.insertCustomer);

router.get('/updateCustomer/:id', customerController.getCustomerById);
router.post('/updateCustomer', customerController.updateCustomer);
module.exports = router;