const express = require("express");
const path = require("path");
const router = express.Router();

router.get('/dashboard', (req, res, next)=>{
    // var session = req.session;
    if(req.session.email  == undefined){
        res.redirect("/auth/login-page");
    }
    else{
        res.render('dashboard');
    }
});

router.get('/', (req, res, next)=>{
    res.render(path.join(__dirname, "../", "views", "auth", "auth-login"));
});


module.exports = router;

