const Sequelize = require("sequelize");

// const sequelize = new Sequelize(
//     'nodedemo',
//     'anas',
//     'password', 
//     {
//         Server: 'localhost',
//         dialect : 'postgres'
//     }
// );

const sequelize = new Sequelize("demo", "root", "Password@123", {
    dialect:"mysql",
    host: 'localhost'
})

// sequelize.authenticate().then(()=>{console.log("")}).catch(err=>{
//     console.log(err)
// })

module.exports = sequelize;