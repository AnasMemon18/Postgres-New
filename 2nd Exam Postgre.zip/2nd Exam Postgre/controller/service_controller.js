const Service = require('../models/service');
const Customer = require('../models/customer');
const path = require("path");
var date = new Date().toISOString().split("T")[0];

const showServices = (req, res, next)=>{
    try {
        Service.findAll({where: { isDeleted: 0 }})
        .then(result => {
            // console.log(result)
            res.render(path.join(__dirname, "../", "views", "service", "showServices"), {services: result});
        })
        .catch(err => {
            throw err;
        })
} catch (err) {
    throw err;
}
};

const addServicePage = (req, res, next)=>{
    try{
        Customer.findAll()
            .then(result=>{
                res.render(path.join(__dirname, "../", "views", "service", "addServicePage"), {customers: result});
            }).catch(err=>{
                console.log(err);
            })
    }catch(err){
        console.log(err)
    }
   
}


const addService = (req, res, next)=>{
    var customer = req.body.customerName;
    var customerId = customer.split(".")[0];
    var customerName = customer.split(". ")[1];
  try {
   {
        Service.create({
            customerName: customerName,
            vehicleNumber: req.body.vehicleNumber,
            pickupDate: req.body.pickupDate,
            dropDate: req.body.dropDate,
            location: req.body.location,
            serviceLocation: req.body.serviceLocation,
            servicePrice: req.body.servicePrice,
            payableAmount: req.body.payableAmount,
            customerId: customerId
        })
            .then((customer) => {
                res.redirect('/service/showServices');
               
            })
            .catch(err => {
                console.log("Insertion Error!");
                throw err;
            })
    }
}
catch (err) {
    throw err;
}
}


const detailsPage = (req, res, next)=>{
    Service.findAll({where: {isDeleted:0}})
        .then(result=>{
        res.render(path.join(__dirname, "../", "views", "service", "details"), {details: result});
    }).catch(err=>{
        console.log(err);
    })
};



const getServiceById = (req, res, next)=>{
    var custData;
    Customer.findAll()
            .then(result=>{
                custData = result
            })
            const id = req.params.id;
    try {
        Service.findByPk(id)
            .then(data => {
                // console.log(data)
                res.render(path.join(__dirname, "../", "views", "service", "updateService"), { date: date, data: data, customers: custData });
            })
            .catch(err => {
                throw err;
            })
    } catch (err) {
        throw err;
    }
};


const updateService = (req, res, next)=>{
    var customer = req.body.customerName;
    var customerId = customer.split(".")[0];
    var customerName = customer.split(". ")[1];
  
    try {
        Service.update({
            customerName: customerName,
            vehicleNumber: req.body.vehicleNumber,
            pickupDate: req.body.pickupDate,
            dropDate: req.body.dropDate,
            location: req.body.location,
            serviceLocation: req.body.serviceLocation,
            servicePrice: req.body.servicePrice,
            payableAmount: req.body.payableAmount,
            customerId: customerId
        }, {
            where: { id: req.body.id }
        }).then(service => {
            res.redirect('/service/showServices');
        }).catch(err => {
            throw err;
        })
    } catch (err) {
        throw err;
    }
};


const deleteService = (req, res, next)=>{
    const id = req.params.id;
    try {
        Customer.update({
          isDeleted: 1
        }, {
            where: { id: id}
        }).then(customer => {
            res.redirect('/service/showServices');
        }).catch(err => {
            throw err;
        })
    } catch (err) {
        throw err;
    }
};





module.exports = {
    showServices,
    addServicePage,
    addService,
    detailsPage,
    getServiceById,
    updateService,
    deleteService
}