const Customer = require('../models/customer');
const path = require("path");
const bcrypt = require("bcrypt");
var date = new Date().toISOString().split("T")[0];

const showCustomers = (req, res, next)=>{
    try {
        Customer.findAll({where: { isDeleted: 0 }})
            .then(result => {
                console.log(result)
                res.render(path.join(__dirname, "../", "views", "customer", "showCustomers"), { customers: result })
            })
            .catch(err => {
                throw err;
            })
    } catch (err) {
        throw err;
    }
};

const insertCustomer = async (req, res, next)=>{
    try {
        const customer = await Customer.findOne({ where: { email: req.body.email } });
        if (customer) {
            try {
                Customer.update({
                  isDeleted: 0
                }, {
                    where: { email: customer.email}
                }).then(customer => {
                    res.redirect('/customer/showCustomers');
                }).catch(err => {
                    throw err;
                })
            
        }catch(err){
            console.log(err);
        }
        
        }else {
            Customer.create({
                name: req.body.name,
                email: req.body.email,
                phoneNumber: req.body.phoneNumber,
                dob: req.body.dob,
                password: await bcrypt.hash(req.body.password, 10),
                country: req.body.country,
                address: req.body.address
            })
                .then((customer) => {
                    res.redirect('/customer/showCustomers');
                   
                })
                .catch(err => {
                    console.log("Insertion Error!");
                    throw err;
                })
        }
    }
    catch (err) {
        throw err;
    }
};


const addCustomerPage = (req, res, next)=>{
    res.render(path.join(__dirname, "../", "views", "customer", "addCustomerPage"));
}


const getCustomerById = (req, res, next)=>{
    const id = req.params.id;
    try {
        Customer.findByPk(id)
            .then(data => {
                console.log(data)
                res.render(path.join(__dirname, "../", "views", "customer", "updateCustomer"), { date: date, data: data });
            })
            .catch(err => {
                throw err;
            })
    } catch (err) {
        throw err;
    }
};

const updateCustomer = (req, res, next)=>{
    try {
        Customer.update({
            name: req.body.name,
            email: req.body.email,
            phoneNumber: req.body.phoneNumber,
            dob: req.body.dob,
            country: req.body.country,
            address: req.body.address      
        }, {
            where: { id: req.body.id }
        }).then(customer => {
            res.redirect('/customer/showCustomers');
        }).catch(err => {
            throw err;
        })
    } catch (err) {
        throw err;
    }
};


const deleteCustomer = (req, res, next)=>{
    const id = req.params.id;
    try {
        Customer.update({
          isDeleted: 1
        }, {
            where: { id: id}
        }).then(customer => {
            res.redirect('/customer/showCustomers');
        }).catch(err => {
            throw err;
        })
    } catch (err) {
        throw err;
    }
};

module.exports = {
    showCustomers,
    insertCustomer,
    addCustomerPage,
    getCustomerById,
    updateCustomer,
    deleteCustomer
}

