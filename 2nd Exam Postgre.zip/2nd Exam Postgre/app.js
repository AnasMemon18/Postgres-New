//Inbuilt & External packages
const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const session = require("express-session");
const cookieParser = require("cookie-parser");

//Database
const sequelize = require('./util/database');
const User = require('./models/user');
const Customer = require('./models/customer');
const Service = require('./models/service');


//Routes
const authRoutes = require('./routes/auth_routes');
const customerRoutes = require('./routes/customer_routes');
const serviceRoutes = require('./routes/service_routes');
const userRoutes = require('./routes/user_routes');
const otherRoutes = require('./routes/other_routes');
const { json } = require("body-parser");

const oneDay = 1000 * 60 * 60 *24;
const app = express();

//Middlewares
app.use(express.static(path.join(__dirname, "public")));
app.use(bodyParser.urlencoded({extended:true}));
app.use(json());

app.use(session({
    secret: "thisismysecretkey",
    saveUninitialized: true,
    cookie: {maxAge: oneDay},
    resave: false
}));
app.use(cookieParser());

app.set("view engine", "ejs");

app.locals.moment = require("moment");

//Main Routes
app.use('/auth', authRoutes);
app.use('/user', userRoutes);
app.use('/customer', customerRoutes);
app.use('/service', serviceRoutes);
app.use(otherRoutes);

Customer.hasMany(Service);

sequelize
    .sync()
    .then(result=>{
    })
    .catch(err=>{
        console.log(err)
    })

app.listen(9999, ()=>console.log("Server started on port 9999"));
