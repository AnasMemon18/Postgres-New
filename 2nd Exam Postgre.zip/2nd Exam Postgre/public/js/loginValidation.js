var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
var otp = /^[0-9]{6}$/;


//eye1
function showPassword() {
  var x = document.getElementById("password");
  if (x.type === "password") {
    x.type = "text";
    document.getElementById("eye1").className = "fa fa-eye-slash";
  } else {
    x.type = "password";
    document.getElementById("eye1").className = "fa fa-eye";
  }
}

//eye2
function showPassword2() {
  var y = document.getElementById("confirmPassword");
  if (y.type === "password") {
    y.type = "text";
    document.getElementById("eye2").className = "fa fa-eye-slash";
  } else {
    y.type = "password";
    document.getElementById("eye2").className = "fa fa-eye";
  }
}

//Email onBlur
function onEmailChange() {
  if (document.getElementById("email").value.match(mailformat)) {
    document.getElementById("email-err").innerHTML = "";
  } else {
    document.getElementById("email-err").innerHTML =
      "Please enter valid email!";
  }
}

//Password onBlur
function onPasswordChange() {
  var password = document.getElementById("password").value;
  if (
    password.length < 6 ||
    /[A-Z]/g.test(password) == false ||
    /\d/g.test(password) == false
  ) {
    document.getElementById("password-err").innerHTML =
      "Password length should be atleast 6. <br /> Password should contain atleast one digit. <br /> Password should contain atleast one capital letter.  ";
  } else {
    document.getElementById("password-err").innerHTML = "";
  }
}



function validateLoginPage() {

  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;

  document.getElementById("submit-login-btn").addEventListener("click", function (event) {
      // Email validation
      if (email.length === 0) {
        event.preventDefault();
        document.getElementById("email-err").innerHTML = "Please enter email!";
        return;
      } else if (!email.match(mailformat)) {
        event.preventDefault();
        document.getElementById("email-err").innerHTML =
          "Please enter valid email!";
        return;
      } else {
        document.getElementById("email-err").innerHTML = "";
      }

      if (
        password.length < 6 ||
        /[A-Z]/g.test(password) == false ||
        /\d/g.test(password) == false
      ) {
        document.getElementById("password-err").innerHTML =
          "Password length should be atleast 6. <br /> Password should contain atleast one digit. <br /> Password should contain atleast one capital letter.  ";
        event.preventDefault();
        return;
      } else if (password == "") {
        event.preventDefault();
        document.getElementById("password-err").innerHTML =
          "Please enter password.";
      } else {
        document.getElementById("password-err").innerHTML = "";
      }
    });
}

