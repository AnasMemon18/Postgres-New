var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
var otp = /^[0-9]{4}$/;

//Email onBlur
function onEmailChange() {
    if (document.getElementById("email").value.match(mailformat)) {
      document.getElementById("email-err").innerHTML = "";
    } else {
      document.getElementById("email-err").innerHTML =
        "Please enter valid email!";
    }
  }


